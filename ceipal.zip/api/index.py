import os
from fastapi import FastAPI, HTTPException
from supabase import create_client, Client
from dotenv import load_dotenv

load_dotenv()

app = FastAPI()

# Initialize Supabase client
url: str = os.environ.get("SUPABASE_URL")
key: str = os.environ.get("SUPABASE_ANON_KEY")

if not url or not key:
    raise RuntimeError("Missing Supabase environment variables")

supabase: Client = create_client(url, key)

@app.get("/api/resumes")
async def search_resumes(query: str = "Cnc machine operator"):
    try:
        # Using Supabase RPC or Table Select to avoid IPv6 Postgres issues
        # This matches against 'job_title' or 'resume_text' in your table
        response = supabase.table("parsed_resumes") \
            .select("id, data->full_name, data->job_title") \
            .or_(f"data->>job_title.ilike.%{query}%,data->>resume_text.ilike.%{query}%") \
            .limit(10) \
            .execute()
            
        return {"data": response.data}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/health")
async def health_check():
    return {"status": "connected", "database": "supabase_rest_api"}